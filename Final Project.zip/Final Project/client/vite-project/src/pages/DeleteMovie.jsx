import React from 'react'

const DeleteMovie = () => {
  return (
    <div>
      
    </div>
  )
}

export default DeleteMovie
