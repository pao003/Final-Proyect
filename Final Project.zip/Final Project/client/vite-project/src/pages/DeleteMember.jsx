import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

const MembersList = () => {
    const [members, setMembers] = useState([]);
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchMembers = async () => {
            try {
                const { data } = await axios.get('http://localhost:3000/members');
                setMembers(data);
            } catch (error) {
                setError('Error fetching members');
            }
        };
        fetchMembers();
    }, []);

    const handleDelete = async (id) => {
        try {
            await axios.delete(`http://localhost:3000/members/${id}`);
            setMembers(members.filter((member) => member._id !== id));
        } catch (error) {
            setError('Error deleting member');
        }
    };

    return (
        <div>
            <h2>All Members</h2>
            {error && <p>{error}</p>}
            <ul>
                {members.map((member) => (
                    <li key={member._id}>
                        {member.name} - {member.email} - {member.city}
                        {/* <button onClick={() => navigate(`/editMember/${member._id}`)}>Edit</button> */}
                        <button onClick={() => handleDelete(member._id)}>Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default MembersList;