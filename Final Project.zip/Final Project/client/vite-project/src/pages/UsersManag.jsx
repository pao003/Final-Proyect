import React from 'react'

const UsersManag = () => {
  return (
    <div>
      
    </div>
  )
}

export default UsersManag
