import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const MEMB_URL = 'http://localhost:3000/members';

const EditMember = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [member, setMember] = useState({
        name: '',
        email: '',
        city: ''
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchMember = async () => {
            try {
                const { data } = await axios.get(`${MEMB_URL}/${id}`);
                setMembersetMember({
                    name: data.name || '',
                    email: data.email || '',
                    city: data.city || ''
                });
            } catch (error) {
                setError('Error fetching member data');
            }
        };
        fetchMember();
    }, [id]);

        const handleChange = (e) => {
            const { name, value } = e.target;
            setMember((prevMember) => ({
            ...prevMember,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            setLoading(true);
            await axios.put(`${MEMB_URL}`, member);
            setLoading(false);
            navigate('/members');
        } catch (error) {
            setError('Error updating member');
            setLoading(false);
        }
    };

    return (
        <div>
            <h2>Edit Member: {member.name}</h2>
            {loading && <p>Loading...</p>}
            {error && <p>{error}</p>}
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Name:</label>
                    <input
                        type="text"
                        name="name"
                        value={member.name}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>Email:</label>
                    <input
                        type="email"
                        name="email"
                        value={member.email}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>City:</label>
                    <input
                        type="text"
                        name="city"
                        value={member.city}
                        onChange={handleChange}
                    />
                </div>
                <button type="submit">Save</button>
            </form>
        </div>
    );
};

export default EditMember;

