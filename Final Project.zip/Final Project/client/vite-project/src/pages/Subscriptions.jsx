import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const MEMB_URL = 'http://localhost:3000/members';

import React from 'react'

const Subscriptions = () => {

    const [members, setMembers] = useState([]);
    // const [member, setMember] = useState({});

    const navigate = useNavigate();

    

    const getAllMembers = async () => {
    const { data } = await axios.get(MEMB_URL);
    setMembers(data);
  };


  return (
    <div>
      <h1> Subscriptions</h1>
        <button onClick={getAllMembers}>All Members</button>
        <button onClick={() => navigate('/addMember')}>Add Member</button>
        <br />
        <ul>
        {members.map((mem) => {
          return <li key={mem._id}>Name: {mem.name}, < br/>
          Email: {mem.email}, < br/>
          City: {mem.city} 
          < br />
          <button onClick={() => navigate('/editMember')}>Edit</button> 
          <button onClick={() => navigate('/deleteMember')}>Delete</button>
          </li>;
        })}
        </ul>
        
      
    </div>
  )
}

export default Subscriptions







// import AllMembers from "./pages/AllMembers"

// const Subscriptions = () => {
//   return (
//     <div style={{ border: '5px solid back', width: '500px'}}>
//             <h1></h1>
            
//             <button onClick>All Members</button>
            
//                 <div>
//                     {movieIds.map((id) => (
//                         <AllMembers key={id} id={id} />
                        
//                     ))}
                    
//                 </div>
                
                
            
            
            
//         </div>
//   )
// }

// export default Subscriptions
