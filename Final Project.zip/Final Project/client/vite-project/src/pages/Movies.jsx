import { useState } from 'react';
import { useNavigate} from 'react-router-dom';
import axios from 'axios';
import Movie from './Movie';


const SHOWS_URL = 'http://localhost:3000/movie';

const Movies = () => {
    

    const [movieIds, setMovieIds] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const navigate = useNavigate();

    const fetchData = async () => {
        try {
            setLoading(true);
            const { data } = await axios.get(SHOWS_URL);
            const ids = data.map((movie) => movie.id);
            setMovieIds(ids);
            setLoading(false);
        } catch (error) {
            setError('Error fetching data');
            setLoading(false);
        }
    };

   

    return (
        <div style={{ border: '5px solid black', width: '500px'}}>
            <h1>Movies</h1>
            
            <button onClick={fetchData}>All Movies</button>
            <button onClick={() => navigate('/movies/add')}>AddMovie</button>
            <br /> <br />
           
         
            {loading && <div>Loading...</div>}
            {error && <div>{error}</div>}
            {movieIds.length > 0 && (
                <div>
                    {movieIds.map((id) => (
                        <Movie key={id} id={id} />
                        
                    ))}
                    
                </div>
                
                
            )}
            
            
        </div>
    );
};

export default Movies;