import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';


const MEMB_URL = 'http://localhost:3000/members';

const AddMember = () => {
    

    const [member, setMember] = useState({
        name: '',
        email: '',
        city: ''
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setMember((prevMember) => ({
            ...prevMember,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            setLoading(true);
            await axios.post(MEMB_URL, member);
            setLoading(false);
            navigate('/addMember');
        } catch (error) {
            setError('Error adding member');
            setLoading(false);
        }
    };

  return (
    <div>
          <div>
            <h2>Add New Member</h2>
            {loading && <p>Loading...</p>}
            {error && <p>{error}</p>}
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Name:</label>
                    <input
                        type="text"
                        name="name"
                        value={member.name}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>Email</label>
                    <input
                        type="email"
                        name="email"
                        value={member.email}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>City</label>
                    <input
                        type="text"
                        name="city"
                        value={member.city}
                        onChange={handleChange}
                    />
                </div>
                
                <button type="submit">Save</button>
                <button onClick={() => navigate('/subscriptions')}>cancel</button>
            </form>
        </div>
      
    </div>
  )
}

export default AddMember
