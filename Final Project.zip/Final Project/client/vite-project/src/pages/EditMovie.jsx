import { useParams, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import axios from 'axios';


const SHOWS_URL = 'http://localhost:3000/movie';
const MOVIE_URL = 'http://localhost:3000/movieUp';

const EditMovie = () => {
    
    const { id } = useParams();
    const navigate = useNavigate();

    const [movie, setMovie] = useState({
        name: '',
        genres: '',
        premiered: '',
        image: ''
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchMovie = async () => {
            try {
                const { data } = await axios.get(`${SHOWS_URL}/${id}`);
                setMovie(data);
            } catch (error) {
                setError('Error fetching movie data');
            }
        };
        fetchMovie();
    }, [id]);

    

        const handleChange = (e) => {
            const { name, value } = e.target;
            setMovie((prevMovie) => ({
            ...prevMovie,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            setLoading(true);
            await axios.post(`${MOVIE_URL}`, movie);
            setLoading(false);
            navigate('/movies');
        } catch (error) {
            setError('Error adding movie');
            setLoading(false);
        }
    };

    return (
        <div>
            <h2>Edit Movie: {movie.name}</h2>
            {loading && <p>Loading...</p>}
            {error && <p>{error}</p>}
            <form onSubmit={handleSubmit}>
              <div>
                <label>Name:</label>
                <input
                type="text"
                name="name"
                value={movie.name}
                onChange={handleChange}
               />
              </div>
            <div>
               <label>Genres:</label>
               <input
               type="text"
               name="genres"
               value={movie.genres}
               onChange={handleChange}
             />
        </div>
        <div>
          <label>Premiered:</label>
          <input
            type="text"
            name="premiered"
            value={movie.premiered}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Image:</label>
          <input
            type="text"
            name="image"
            value={movie.image}
            onChange={handleChange}
          />
        </div>
        <button type="submit">Update</button>
        
        <button onClick={() => navigate('/movies')}>cancel</button>
       
      </form>
        </div>
    );
};

export default EditMovie;


