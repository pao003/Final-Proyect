import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const MOVIE_URL = 'http://localhost:3000/movieUp';

const AddMovie = () => {
    const navigate = useNavigate();

    const [movie, setMovie] = useState({
        name: '',
        genres: '',
        premiered: '',
        image: ''
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setMovie((prevMovie) => ({
            ...prevMovie,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            setLoading(true);
            await axios.post(MOVIE_URL, movie);
            setLoading(false);
            navigate('/movies');
        } catch (error) {
            setError('Error adding movie');
            setLoading(false);
        }
    };

    return (
        <div>
            <h2>Add New Movie</h2>
            {loading && <p>Loading...</p>}
            {error && <p>{error}</p>}
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Name:</label>
                    <input
                        type="text"
                        name="name"
                        value={movie.name}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>Genres:</label>
                    <input
                        type="text"
                        name="genres"
                        value={movie.genres}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>Premiered:</label>
                    <input
                        type="text"
                        name="premiered"
                        value={movie.premiered}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>Image URL:</label>
                    <input
                        type="text"
                        name="image"
                        value={movie.image}
                        onChange={handleChange}
                    />
                </div>
                <button type="submit">Save</button>
                <button onClick={() => navigate('/movies')}>cancel</button>
            </form>
        </div>
    );
};

export default AddMovie;
