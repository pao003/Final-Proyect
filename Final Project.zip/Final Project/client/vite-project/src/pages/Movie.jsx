import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const SHOWS_URL = 'http://localhost:3000/movie';

const Movie = ({ id }) => {
    const [movies, setMovies] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);


    const navigate = useNavigate();

    

    useEffect(() => {
        const fetchMovie = async () => {
            try {
                setLoading(true);
                const { data } = await axios.get(SHOWS_URL);
                setMovies(data);
                setLoading(false);
            } catch (error) {
                setError('Error fetching movie data');
                setLoading(false);
            }
        };
        fetchMovie();
    }, [id]);



    if (loading) return <div>Loading...</div>;
    if (error) return <div>{error}</div>;

    return (
        <div style={{ border: '5px solid black', width: '300px' }}>
            {movies.map((movie) => (
                <div key={movie.id}>
                    <h2>{movie.name}</h2>
                    <p>Year: {movie.premiered}</p>
                    <p>Genres: {movie.genres && movie.genres.join(', ')}</p>
                    {movie.image && <img src={movie.image.medium} alt={movie.name} />}
                    <br />
                    
                    <button onClick={() => navigate(`/edit/${movie.id}`)}>Edit</button>
                    
                    <button onClick={() => navigate('/delete')}>Delete</button>
            </div>
            ))}
        
        </div>
    );
};

export default Movie;