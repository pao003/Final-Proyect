const moviesRepo = require('../repositories/movieUpRepo');

const getAllMovies = (filters) => {
  return moviesRepo.getAllMovies(filters);
};

const getMovieById = (id) => {
  return moviesRepo.getMovieById(id);
};

const addMovie = (obj) => {
  return moviesRepo.addMovie(obj);
};

const updateMovie = (id, obj) => {
  return persRepo.updateMovie(id, obj);
};

const deleteMovie = (id) => {
  return moviesRepo.deleteMovie(id);
};

  
module.exports = { getAllMovies, getMovieById, addMovie, updateMovie, deleteMovie };