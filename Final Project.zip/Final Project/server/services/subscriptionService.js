// const Subscription = require('../models/Subscription');

// const getSubscriptions = async (req, res) => {
//   try {
//     const subscriptions = await Subscription.find().populate('movieId memberId');
//     res.status(200).json(subscriptions);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

// const addSubscription = async (req, res) => {
//   try {
//     const { movieId, memberId, date } = req.body;
//     const newSubscription = new Subscription({ movieId, memberId, date });
//     await newSubscription.save();
//     res.status(201).json(newSubscription);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

// module.exports = { getSubscriptions, addSubscription };