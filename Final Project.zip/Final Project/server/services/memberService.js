const memberRepo = require ('../repositories/memberRepo');

const getAllMembers = (filters) => {
  return memberRepo.getAllMembers(filters);
};

const getMemberById = (id) => {
  return memberRepo.getMemberById(id);
};

const addMember = (obj) => {
  return memberRepo.addMember(obj);
};

const updateMember = (id, obj) => {
  return memberRepo.updateMember(id, obj);
};

const deleteMember = (id) => {
  return moviesRepo.deleteMovie(id);
};

  
module.exports = { getAllMembers, getMemberById, addMember, updateMember, deleteMember };


// const Member = require('../models/Member');

// const getMembers = async (req, res) => {
//   try {
//     const members = await Member.find();
//     res.status(200).json(members);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

// const addMember = async (req, res) => {
//   try {
//     const { email, city } = req.body;
//     const newMember = new Member({ email, city });
//     await newMember.save();
//     res.status(201).json(newMember);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

// const updateMember = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const updatedMember = await Member.findByIdAndUpdate(id, req.body, { new: true });
//     res.status(200).json(updatedMember);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

// const deleteMember = async (req, res) => {
//   try {
//     const { id } = req.params;
//     await Member.findByIdAndDelete(id);
//     res.status(200).json({ message: 'Member deleted successfully' });
//   } catch (error) {
//     res.status(500).json({error: error.message });
//   }
// };

// module.exports = { getMembers, addMember, updateMember, deleteMember };