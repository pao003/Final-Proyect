const moviesRepo = require('../repositories/movieRepo');

const getAllMovies = async () => {
  let { data: movies } = await moviesRepo.getAllMovies();
  
  movies = movies.map((movie) => {
    return {
      id: movie.id,
      name: movie.name,
      premiered: movie.premiered,
      genres: movie.genres,
      image: movie.image.medium,
    };
  });
  
  return movies;
};

const getMovieById = async (id) => {
  const { data: movie } = await moviesRepo.getMovieById(id);

  return {
    id: movie.id,
    name: movie.name,
    genres: movie.genres,
    premiered: movie.premiered,
    image: movie.image ? movie.image.medium : null,
  };
};

  
// const deleteMovie = (id) => {
//   return moviesRepo.deleteMovie(id);
// };

// const updateMovie = (id, obj) => {
//   return persRepo.updatePerson(id, obj);
// };


  
module.exports = { getAllMovies, getMovieById };
  
//   const getAllCities = async () => {
//     try {
//       const persons = await getAllPersons();
//       const cities = persons.map((per) => per.city);
//       return cities;
//     } catch (error) {
//       return error;
//     }
//   };
  
//   const getMovieById = (id) => {
//     return movieRepo.getMovieById(id);
//   };
  
//   const addMovie = (obj) => {
//     return movieRepo.addMovie(obj);
//   };
  
//   const updateMovie = (id, obj) => {
//     return movieRepo.updateMovie(id, obj);
//   };
  
//   const deleteMovie = (id) => {
//     return movieRepo.deleteMovie(id);
//   };
  
//   module.exports = {
//     getAllMovies,
//     getMovieById,
//     addMovie,
//     updateMovie,
//     deleteMovie,
//   };