const Member = require ('../models/memberModel');
// const { default: Movie } = require('../../client/vite-project/src/pages/Movie');

const getAllMembers = (filters) => {
  return Member.find(filters);
};

const getMemberById = (id) => {
  return Member.findById(id);
};

const addMember = (obj) => {
    const mem = new Member(obj);
    return mem.save();
  };

const updateMember = (id, obj) => {
  return Member.findByIdAndUpdate(id, obj);
};

const deleteMember = (id) => {
  return Member.findByIdAndDelete(id);
};

module.exports = { getAllMembers, getMemberById, addMember, updateMember, deleteMember};