const axios = require('axios');
// const { get } = require('mongoose');
const Movie = require('../models/movieUpModel');
// const { default: Movie } = require('../../client/vite-project/src/pages/Movie');

const SHOWS_URL = 'https://api.tvmaze.com/shows';

const getAllMovies = () => {
    return axios.get(SHOWS_URL);
};

const getMovieById = (id) => {
    return axios.get(`${SHOWS_URL}/${id}`);
};

// const updateMovie = (id, obj) => {
//   return Movie.findByIdAndUpdate(id, obj); // Usando mongoose para actualizar
// };


module.exports = { getAllMovies, getMovieById};

// const Movie = require('../models/movieModel');


// const getAllMovies = (filters) => {
//   return Person.find(filters);
// };

// const getMovieById = (id) => {
//   return Person.findById(id);
// };

// const addMovie = (obj) => {
//   const per = new Movie(obj);
//   return per.save();
// };

// const updateMovie = (id, obj) => {
//   return Movie.findByIdAndUpdate(id, obj);
// };

// const deleteMovie = (id) => {
//   return Movie.findByIdAndDelete(id);
// };

// module.exports = {
//   getAllMovies,
//   getMovieById,
//   addMovie,
//   updateMovie,
//   deleteMovie,
// };