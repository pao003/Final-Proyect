// const mongoose = require('mongoose');

// const subscriptionSchema = new mongoose.Schema(
//   {
//     movieId: { type: mongoose.Schema.Types.ObjectId, ref: 'Movie', required: true },
//     memberId: { type: mongoose.Schema.Types.ObjectId, ref: 'Member', required: true },
//     date: Date
//   },
//   { versionKey: false }
// );

// const Subscription = mongoose.model('subscription', subscriptionSchema);

// module.exports = Subscription;

