const express = require('express');
const axios = require('axios');
const cors = require('cors');
const connectDB = require('./configs/db');

// const userController = require('./controllers/carsController');
const moviesController = require('./controllers/movieController');
const movieUpController = require('./controllers/movieUpController');
const memberController = require('./controllers/memberController');
// const subscriptionController = require('./controllers/subscriptionController');


const app = express();
const PORT = 3000;

connectDB();


app.use(cors());

app.use(express.json());

// app.use('/users', userController); 
app.use('/movie', moviesController); 
app.use('/movieUp', movieUpController);
app.use('/members', memberController); 
// app.use('/subscription', subscriptionController);

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});