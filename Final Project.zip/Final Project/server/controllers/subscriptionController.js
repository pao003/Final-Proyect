// const express = require('express');
// const subscriptionService = require('../services/subscriptionService');

// const router = express.Router();


// router.get('/', async (req, res) => {
//     try {
//       const filters = req.query;
//       const members = await subscriptionService.getAllMembers(filters);
//       res.send(members);
//     } catch (error) {
//       res.send(error);
//     }
//   });


// router.post('/', async (req, res) => {
//     try {
//       const obj = req.body;
//       const result = await subscriptionService.addMember(obj);
//       res.status(201).send(result);
//     } catch (error) {
//       res.send(error);
//     }
//   });
// module.exports = router;