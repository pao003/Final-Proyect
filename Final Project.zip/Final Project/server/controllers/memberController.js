const express = require('express');
const memberService = require('../services/memberService');

const router = express.Router();


router.get('/', async (req, res) => {
    try {
        const filters = req.query;
        const member = await memberService.getAllMembers(filters);
        res.send(member);
    } catch (error) {
        res.send(error);
    }
});

router.get('/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const member = await memberService.getMemberById(id);
      res.send(member);
    } catch (error) {
      res.send(error);
    }
  });

router.post('/', async (req, res) => {
    try {
        const obj = req.body;
        const result = await memberService.addMember(obj);
        res.status(201).send(result);
    } catch (error) {
        res.send(error);
    }
});

router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const obj = req.body;
        const result = await memberService.updateMember(id, obj);
        res.send(result);
    } catch (error) {
        res.send(error);
    }
});

router.delete('/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const result = await memberService.deleteMember(id);
      res.send(result);
    } catch (error) {
      res.send(error);
    }
  });

module.exports = router;