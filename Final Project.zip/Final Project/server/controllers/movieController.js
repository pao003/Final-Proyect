const express = require('express');
const moviesService = require('../services/movieService');

const router = express.Router();

router.get('/', async (req, res) => {
    try {
      // const filters = req.query;
      const movies = await moviesService.getAllMovies();
      res.send(movies);
    } catch (error) {
      res.send(error);
    }
});

router.get('/:id?', async (req, res) => {
     try {
       const movie = await moviesService.getMovieById(req.params.id);
       res.send(movie);
    }  catch (error) {
       res.status(500).json({ message: 'Error fetching movie' });
    }
});



module.exports = router;

// router.get('/:id', async (req, res) => {
//     try {
//       const { id } = req.params;
//       const movie = await movieService.getById(id);
//       res.send(movie);
//     } catch (error) {
//       res.send(error);
//     }
//   });

// router.post('/', async (req, res) => {
//     try {
//         const obj = req.body;
//         const result = await movieService.addMovie(obj);
//         res.status(201).send(result);
//     } catch (error) {
//         res.send(error);
//     }
// });

// router.put('/:id', async (req, res) => {
//     try {
//         const { id } = req.params;
//         const obj = req.body;
//         const result = await persService.updatePerson(id, obj);
//         res.send(result);
//     } catch (error) {
//         res.send(error);
//     }
// });

// router.delete('/:id', async (req, res) => {
//     try {
//       const { id } = req.params;
//       const result = await movieService.deleteMovie(id);
//       res.send(result);
//     } catch (error) {
//       res.send(error);
//     }
//   });

// module.exports = router;